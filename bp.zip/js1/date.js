let d = new Date() ;
let m = d.getMonth();
let dd = d.getDate();
let M = "";
const months = [
	"Январь", 
	"Февраль", 
	"Март", 
	"Апрель", 
	"Май", 
	"Июнь", 
	"Июль", 
	"Август", 
	"Сентябрь", 
	"Октябрь", 
	"Ноябрь", 
	"Декабрь"
];

M = months[m] ;