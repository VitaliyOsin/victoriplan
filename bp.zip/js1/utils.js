const cel = el => document.createElement(el);
const gel = el => document.getElementById(el);
const qel = el => document.querySelector(el);
const qell = el => document.querySelectorAll(el);
